<?php
namespace app\controllers;
use app\App;
use app\AuthService;
use app\Controller;
use app\helpers\Alert;
use app\helpers\MetaTagManager;
use app\models\Shezhire;
use app\models\User;
use app\Response;


class SiteController extends Controller {

//    public string $layout = 'new';
    public function actionIndex() {
        
        MetaTagManager::register(['asdf' => 'cofg']);

        $user = User::find()->all();

        return $this->render('index', [
            'id' => 123,
            'users' => $user
        ]);
    }

    public function actionView($id)
    {
        $model = User::find()->where(['id' => $id])->one();

        return $this->render('view', [
            'model' => $model
        ]);
    }

    public function actionAdd()
    {

        if($this->user->isGuest()){
            Alert::add('danger', 'Please login');
            return $this->redirect('/');
        }

        $model = new User();

        if($this->request->isPost() && $model->load($this->request->post())){
//            $model->login = $this->request->post('login');
//            $model->password = $this->request->post('password');
            $model->save();

            return $this->redirect('/');

        }

        return $this->render('add', [
            'model' => $model
        ]);

    }

    public function actionDelete($id)
    {

        $user = User::find()->where(['id' => $id])->one();

        if(!$user){
            Alert::add("danger", "Cant find row");
            return $this->redirect(['site/index']);
        }

        $user->delete();

        Alert::add("warning", "Успешно удалено");

        $this->redirect('/');

    }

    public function actionLogin()
    {

        $model = new User();

        if($this->request->isPost()){
            $ok = $this->user::login($_POST['login'], $_POST['password']);
            if ($ok) {
                Alert::add('success', 'Logged');
                return Response::redirect(['site/index']);
            }
            else{
                Alert::add('danger', 'Wrong');
                return Response::redirect(['site/login']);
            }
        }

        return $this->render('login', [
            'model' => $model
        ]);
    }

    public function actionTest()
    {
        $model = new User();

        if((new App())->request->isPost()){
            $model->login = $this->request->post('login');
            $model->password = $this->request->post('password');
            $model->save();

            return $this->redirect('/');

        }

        return $this->render('add', [
            'model' => $model
        ]);
    }
    public function actionUpdate($id)
    {
        $model = User::find()->where(['id' => $id])->one();

        if($this->request->isPost() && $model->load($this->request->post())){



//            $this->dd($this->request->post());

//            $model->login = $this->request->post('login');
//            $model->password = $this->request->post('password');
//            $model->token = $this->request->post('token');
            $model->save();

            return $this->redirect('/');

        }

        return $this->render('update', [
            'model' => $model
        ]);
    }

    public function actionAjax()
    {

        return $this->response->json([
            'code' => 200
        ]);

    }

    public function actionLogout()
    {
        $this->user->logout();
        Alert::add('warning', 'Logged out');
        return $this->redirect('/');
    }

    public function actionRecursion()
    {

        $model = Shezhire::find()->where(['id' => 1])->one();

        return $this->renderPartial('recursion', [
            'model' => $model
        ]);

    }

    public function actionLoad($id)
    {
        $model = Shezhire::find()->where(['parent_id' => $id])->all();

        return $this->response->json($model);
    }

}
