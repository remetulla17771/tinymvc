let alerts = document.querySelectorAll('.alert')
if (alerts) {
    alerts.forEach(alertItem => {
        alertItem.querySelector('.btn').addEventListener('click', e => {
            alertItem.remove();
        })
    })
}
let dataConfirm = document.querySelectorAll('[data-confirm]');
if (dataConfirm) {
    dataConfirm.forEach(data => {
        data.addEventListener('click', (e) => {
            e.preventDefault();
            console.log(data)
            let confirmDetail = confirm(data.getAttribute('data-confirm'));
            if (confirmDetail) {
                window.location = data.getAttribute('href');
            }

        })
    })
}

window.Modal = {
    open(id) {
        const modal = document.getElementById(id);
        if (!modal) return;

        modal.style.display = 'block';

        const body = modal.querySelector('.modal-body');
        const url = body.dataset.ajax;

        if (url && !body.dataset.loaded) {
            fetch(url)
                .then(r => r.text())
                .then(html => {
                    body.innerHTML = html;
                    body.dataset.loaded = '1';
                });
        }
    },

    close(id) {
        const modal = document.getElementById(id);
        if (modal) modal.style.display = 'none';
    }
}