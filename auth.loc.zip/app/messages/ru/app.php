<?php

return [
    'hello' => 'Привет',
    'User not found' => 'Пользователь не найден',
];
