<h1>Ошибка <?= $code ?></h1>

<p><?= htmlspecialchars($message) ?></p>

<a href="/">На главную</a>
