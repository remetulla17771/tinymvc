<?php

use app\ErrorHandler;

ob_start();
session_start();





spl_autoload_register(function ($class) {
    $prefix = 'app\\';
    $baseDir = __DIR__ . '/../app/';
    if (strncmp($prefix, $class, strlen($prefix)) !== 0) return;
    $relativeClass = substr($class, strlen($prefix));
    $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';
    if (file_exists($file)) require $file;
});

// ✅ РЕГИСТРИРУЕМ ОБРАБОТЧИК ОШИБОК
ErrorHandler::register();

$app = new app\App();
echo $app->run();
