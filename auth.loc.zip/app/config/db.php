<?php


return [
    'dsn' => 'mysql:host=localhost;dbname=auth;charset=utf8',
    'user' => 'root',
    'password' => 'root',
];
